<html>
  <head>
    <title>Blog</title>
  </head>
  <body>

  <img src="Downloads/provolone.png" width="50%" height="50%">
    
    <?php 
    
     echo '<pReceitas com provolone</p>';
    
     echo 'Pão recheado com escarola, provolone e calabresa: esta receita é uma explosão de sabores. Para começar, prepare a massa do pão e deixe crescer. Enquanto isso, prepare o recheio da escarola com alho, cebola, tomate seco, orégano ou tomilho e sal e pimenta a gosto. Pique a linguiça calabresa em fatias. Para montar, abra a massa, coloque as fatias de calabresa, o recheio de escarola e o queijo. Enrole como um rocambole e ponha para assar.';


    ?> 

  <script src="https://replit.com/public/js/replit-badge-v2.js" theme="dark" position="bottom-right"></script>
  </body>
</html>