<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <title> PHP</title>
</head>

<body>
    <?php
        include('config.php');

        //Através do método get, conseguimos capturar os dados dos campos do formulário e armazenar em variáveis locais
        //que serão usadas para compôr a instrução SQL e assim os dados serão armazenados no banco de dados.
        $nome = $_GET["nome"];
        $endereco = $_GET["endereco"];
        $idade = $_GET["idade"];
        $botao = $_GET["botao"];


        //Aqui armazenamos em uma variável, uma string que representa a instrução para inserir os dados no banco de dados.
        $instrucao = "delete from tabela where nome like '".$botao."'";
        
        //Nesta linha teremos apenas uma exibição da tela, se como ficou montada a string.
        echo $instrucao."<br />";

        //para executar a instrução SQL, a função mysqli_query deve ser chamada, passando como parâmetro a variável de conexão e a instrução SQL,
        mysqli_query($conexao, $instrucao);

        //Após realizada a instrução, podemos fechar a conexao com o banco de dados, por meio da função msqli_close
        mysqli_close($conexao);
    ?>
    <br><br>
    <a href="index.html"> Cadastro </a> - <a href="listar.php"> Listar </a> - <a href="alterar.php">Alterar 1 </a> - <a
        href="alterar2.php"> Alterar 2</a> - <a href="excluir.php"> Excluir </a> <br>
    <hr>
</body>
</html>