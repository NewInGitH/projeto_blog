<?php
    //declarando as variáveis para conexão
    $servername = "localhost";
    $database = "aula";
    $username = "root";
    $password = "";

    //criando conexão
    $conexao = mysqli_connect($servername, $username, $password, $database);

    //Checando a conexão
    if (!$conexao) {
        die("Falha na conexão " . mysqli_connect_error());
    }

    //echo "Conectado com sucesso. <br><br>";

// Query para buscar os posts
$sql = "SELECT id, title, content, created_at FROM posts";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Exibindo os posts
    while ($row = $result->fetch_assoc()) {
        echo "<h2>" . $row["title"] . "</h2>";
        echo "<p>" . $row["content"] . "</p>";
        echo "<p>Publicado em: " . $row["created_at"] . "</p>";
        // Aqui você pode adicionar a lógica para exibir os comentários de cada post
    }
} else {
    echo "Nenhum post encontrado.";
}

$conn->close();
?>
?>